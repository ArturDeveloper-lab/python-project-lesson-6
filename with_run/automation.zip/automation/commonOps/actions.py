import time
from page_objects import PageObject
from selenium.webdriver import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.wait import WebDriverWait
from webdriver_manager import driver




class Actions(PageObject):
    def __init__(self, driver):
        super().__init__(driver)
        # self.wait_ec = WebDriverWait(self.driver, 10)

    def click(self, element: WebElement, time_out: int):
        self.w.wait_until(lambda f: element.is_displayed(), time_out)
        element.click()

    # not working
    def click_explicity_wait(self, element: WebElement):
        wait =WebDriverWait(driver, 120)
        (wait.until(EC.element_to_be_clickable(element))).click()



    def insert_text(self, element: WebElement, text: str, time_out: int):
        self.w.wait_until(lambda f: element.is_displayed(), time_out)
        element.send_keys(text)

    def click_js(self, element: WebElement, time_out: int):
        self.w.wait_until(lambda f: element.is_displayed(), time_out)
        self.w.click_js(element)

    def click_specific_js(self, element: WebElement, time_out: int):
        self.w.wait_until(lambda f: element.is_displayed(), time_out)
        self.w.execute_script(f"document.evaluate(\"// input[ @ placeholder = 'Search Accounts...']\", "
                              f"document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()")


    def click_specific_js_no_follow(self, element: WebElement, time_out: int):
        self.w.wait_until(lambda f: element.is_displayed(), time_out)
        self.w.execute_script(f"document.evaluate(\"(//span[@class='slds-radio_faux'])[5]\", "
                              f"document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()")

    def click_on_first_risck_factor(self, element: WebElement, time_out: int):
        self.w.wait_until(lambda f: element.is_displayed(), time_out)
        self.w.execute_script(f"document.evaluate(\"(//a[@class = 'flex-wrap-ie11 slds-truncate'])[5]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()")


    def click_on_releated_tab_risk(self, element: WebElement, time_out: int):
        self.w.wait_until(lambda f: element.is_displayed(), time_out)
        self.w.execute_script(f"document.evaluate(\"(//a[@id ='relatedListsTab__item'])[2]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()")



    def get_text(self, element: WebElement):
        # self.w.wait_until(lambda f: el.is_displayed(), time_out)
        time.sleep(2)
        return element.text

    def get_value(self, element: WebElement):
        time.sleep(2)
        return element.get_attribute('value')

    def is_displayed(self, element: WebElement, timeout: int):
        return bool(self.w.wait_until(lambda f: element.is_displayed(), timeout))

    def is_selected(self, element: WebElement, timeout: int):
        return bool(self.w.wait_until(lambda f: element.is_selected(), timeout))



    def refresh(self):
        time.sleep(5)
        self.w.refresh()
        time.sleep(5)

    # def scroll_from_to(self, start: int, end: int):
    #     self.w.execute_script(f"window.scrollBy({start}, {end}")
    #
    # def scroll_to_element(self, element: WebElement, time_out: int):
    #     self.w.wait_until(lambda f: element.is_displayed(), time_out)
    #     action = ActionChains(driver)
    #     action.move_to_element(element).perform()
    #     # self.w.execute_script("arguments[0].scrollIntoView();", element)

    def scroll_to_end_page(self):
        self.w.scroll("window.scrollTo(0, document.body.scrollHeight);")


    # def scroll(self, start: int, end: int):
    #     self.w.execute_script(f"window.scrollBy({start}, {end}")
    #
    # def scroll(self, element: WebElement, time_out: int):
    #     self.w.wait_until(lambda f: element.is_displayed(), time_out)
    #     self.w.execute_script("arguments[0].scrollIntoView();", element)
    #
    # def scroll(self):
    #     self.w.execute_script("window.scrollBy(0,document.body.scroollHeight)")
