import time

from commonOps.actions import Actions
from ui.age_assured.pages.action_execution import Action_execution
from ui.age_assured.pages.base_page import BasePage
from ui.age_assured.pages.block_program_member_association import BlockProgramMemberAssociation
from ui.age_assured.pages.care_kickoff import CareKickoffPage
from ui.age_assured.pages.contacts import Contact
from ui.age_assured.pages.form_onbourding_tab import Form_onbourding_tab
from ui.age_assured.pages.login_page import LoginPage
from ui.age_assured.pages.main_page import MainPage
from ui.age_assured.pages.make_a_call_screen import MakeACallScreen
from ui.age_assured.pages.specific_contact import MemberObject
from ui.age_assured.pages.new_contact_new_policy_holder import NewContact_New_Policy_Holder
from ui.age_assured.pages.next_step_screen import NextStepScreen
from ui.age_assured.pages.next_step import Next_step
from ui.age_assured.pages.onboarding_tab import Onboardingtab
from ui.age_assured.pages.onbourding import Onbourding_screen
from ui.age_assured.pages.validate_call_screen import ValidateCallScreen
from ui.neverstop.pages.maim_page_ns import  Maim_page_ns


class PagesInit(LoginPage, MainPage, Contact, NewContact_New_Policy_Holder, BlockProgramMemberAssociation, MemberObject, Next_step, BasePage,Action_execution, Onbourding_screen, ValidateCallScreen, NextStepScreen, MakeACallScreen, CareKickoffPage, Onboardingtab, Form_onbourding_tab, Maim_page_ns):
    def __init__(self, driver):
        super().__init__(driver)
        self.login_page = LoginPage(driver)
        self.main_page = MainPage(driver)
        self.contact = Contact(driver)
        self.newContact_New_Policy_Holder = NewContact_New_Policy_Holder(driver)
        self.blockProgramMemberAssociation = BlockProgramMemberAssociation(driver)
        self.memberObject = MemberObject(driver)
        self.basePage = BasePage(driver)
        self.validateCallScreen = ValidateCallScreen(driver)
        self.onbourding_screen = Onbourding_screen(driver)
        self.nextStepScreenFunction = NextStepScreen(driver)
        self.next_step = Next_step(driver)
        self.makeACallScreen = MakeACallScreen(driver)
        self.careKickofPage = CareKickoffPage(driver)
        self.onboardingtab = Onboardingtab(driver)
        self.form_onbourding_tab = Form_onbourding_tab(driver)
        self.action_execution = Action_execution(driver)
        self.maim_page_ns = Maim_page_ns(driver)



    def refresh(self):
        time.sleep(5)
        self.w.refresh()
        time.sleep(5)


