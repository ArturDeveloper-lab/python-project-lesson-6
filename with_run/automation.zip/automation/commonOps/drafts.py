


#     print(dirname(dirname(__file__)))


# from datetime import datetime
#
# import boto3
#
# if __name__ == '__main__':
#
#     s3 = boto3.client("s3")
#     s3_prefix = f"reports/{datetime.utcnow().isoformat()}/"
#
#     # for file_name in []
#
#     s3.upload_file(
#         '/Users/artur_boltyansky/Development_Assured/Automation_ui/automation/reports/allure_reports/index.html',
#         "assuredallies-test-automation", s3_prefix + 'index.html', ExtraArgs=dict(ContentType='text/html'))
#
#     s3.upload_file(
#         '/Users/artur_boltyansky/Development_Assured/Automation_ui/automation/reports/allure_reports/styles.css',
#         "assuredallies-test-automation", s3_prefix + 'styles.css')
#
#     s3.upload_file(
#         '/Users/artur_boltyansky/Development_Assured/Automation_ui/automation/reports/allure_reports/favicon.ico',
#         "assuredallies-test-automation", s3_prefix + 'favicon.ico')
#
#     s3.upload_file(
#         '/Users/artur_boltyansky/Development_Assured/Automation_ui/automation/reports/allure_reports/app.js',
#         "assuredallies-test-automation", s3_prefix + 'app.js')