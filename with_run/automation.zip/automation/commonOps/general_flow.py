import time

from commonOps.pages_init import PagesInit


class General_flow(PagesInit):


    # def create_member(self, sf_object_to_fields):
    #     self.go_to_contacts()
    #     print("contact screen is open")
    #     time.sleep(2)
    #     self.click_newcontactbutton()
    #     print("click on the 'new' button to create new member")
    #
    #     # sf_object_to_fields = {'Contact':
    #     #     {
    #     #         'CONTACT_FIRST_NAME': 'Ruth',
    #     #         'CONTACT_LAST_NAME': 'Yarus'
    #     #     }
    #     # }
    #     contact_field_to_value = sf_object_to_fields['Contact']
    #     self.create_user_data(contact_field_to_value)
    #     time.sleep(3)
    #     self.got_to_block_program_member_association()
    #     self.create_block_program()
    #     print("created block program")
    #     # self.referesh()
    #     # time.sleep(3)
    #     self.go_to_contact()
    #     self.closeTabs()
    #     self.refresh()

    # def create_member(self, first_name: str = None, last_name: str = None, middle_name: str = None):
    #     self.go_to_contacts()
    #     print("contact screen is open")
    #     time.sleep(2)
    #     self.click_newcontactbutton()
    #     print("click on the 'new' button to create new member")
    #     # self.create_user_data(first_name="qa",last_name="ffff")
    #     self.create_user_data(first_name,last_name,middle_name)
    #     time.sleep(3)
    #     self.got_to_block_program_member_association()
    #     self.create_block_program()
    #     print("created block program")
    #     # self.referesh()
    #     # time.sleep(3)
    #     self.go_to_contact()
    #     self.closeTabs()
    #     self.refresh()


    def create_member(self):
        self.go_to_contacts()
        print("contact screen is open")
        time.sleep(2)
        self.click_newcontactbutton()
        print("click on the 'new' button to create new member")
        self.creaute_user_data_init()
        # self.create_user_data()
        time.sleep(3)
        self.got_to_block_program_member_association()
        self.create_block_program()
        print("created block program")
        # self.referesh()
        # time.sleep(3)
        self.go_to_contact()
        self.closeTabs()
        self.refresh()

    # def create_member(self):
    #     self.go_to_contacts()
    #     print("contact screen is open")
    #     time.sleep(2)
    #     self.click_newcontactbutton()
    #     print("click on the 'new' button to create new member")
    #     self.create_user_data()
    #     time.sleep(3)
    #     self.got_to_block_program_member_association()
    #     self.create_block_program()
    #     print("created block program")
    #     # self.referesh()
    #     # time.sleep(3)
    #     self.go_to_contact()
    #     self.closeTabs()
    #     self.refresh()

    def onbourding_flow(self):
        self.closeTabs()
        self.create_member()
        self.go_to_created_member()
        print("click on the created member in home screen")
        self.go_actions_section()
        print("click on the add button to display all section of functionality")
        self.onbourding_section()
        print("select onbourding")
        self.click_on_next_button()
        self.select_all_question_yes()
        self.click_on_next_button()
        self.onbourding_question_high_resolution()
        time.sleep(2)
        self.click_on_next_button()
        time.sleep(3)
        self.select_no_follow_up()
        time.sleep(2)
        self.click_on_next_button()
        self.go_to_member()
        print("click on the member after onbourding process")

    def care_kicoff_flow(self):
        self.go_actions_section()
        self.care_cikof_section()
        self.click_on_next_button()
        self.select_all_question_yes()
        self.click_on_next_button()
        self.select_form()
        self.click_on_next_button()
        print("Care Kickoff page is open start verification of text and select actions")
        print("Finished checked selected checkbox\n")
        self.select_complex_chronic()
        print("Select the ->Complex Chronic Conditions - Inadherence to Care Plan Actions")
        self.select_complex_Chronic_action_send_vitals()
        self.select_action_Arrange_home_modification()
        self.select_action_send_assistive_device()
        self.insert_text_in_text_box_carkicof()
        print("Inset text in text box in the carekicof page ")
        self.select_yes_carkicof_compleate_call()
        self.click_on_next_button()
        time.sleep(2)
        self.select_no_follow_up()
        time.sleep(2)
        self.click_on_next_button()
