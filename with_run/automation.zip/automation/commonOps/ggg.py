
import json
# fruits = ["Strawberries", "Nectarines", "Apples", "Grapes", "Peaches", "Cherries", "Pears"]
# print(fruits[-8])
import os
from os.path import dirname

import boto3

json_file = open(dirname(dirname(__file__)) +'/commonOps/data.json', 'r')
json_data = json_file.read()
json_obj = json.loads(json_data)
print(json_obj)
print(str(json_obj["user_data_type_1"]["first_name"]))


# def connect_to_secret_maneger(param):
#     # credentialAWS = json.loads(boto3.client(service_name='secretsmanager', region_name='us-east-1').get_secret_value(SecretId='SF_CRED_automation_full')['SecretString'])
#     credentialAWS = json.loads(boto3.client(service_name='secretsmanager', region_name='us-east-1').get_secret_value(SecretId='SF_CRED_automation_'+os.environ['ENVIRONMENT_SECRET'])['SecretString'])
#     # print(credentialAWS["user_name"])
#     # print(credentialAWS["password"])
#     # print("aaaa "+os.environ['ENVIRONMENT'])
#     return credentialAWS[param]
#
#
# if __name__ == '__main__':
#     connect_to_secret_maneger()