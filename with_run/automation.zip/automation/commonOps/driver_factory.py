import os
from dataclasses import dataclass


from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException, ElementNotInteractableException, \
    StaleElementReferenceException, ElementClickInterceptedException, ElementNotVisibleException, WebDriverException
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.wait import WebDriverWait
from webdriver_manager import driver
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager



@dataclass
class DriverFactory:
    """Responsible for the driver initialization. It allows us to init driver on demand"""

    @staticmethod
    def _driver_init(browser: str):
        driver = None
        if browser == 'chrome':
            options = webdriver.ChromeOptions()
            # set headless mode with environment variable  True ,without variable no-headless mode
            # options.headless = True
            # options.headless = bool(os.environ['HEADLESS'])
            driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
        elif browser == 'firefox':
            driver = webdriver.Firefox(executable_path=GeckoDriverManager().install())
        return driver

    def get_driver(self, wait_time: int = 10, browser: str = 'chrome'):
        driver = self._driver_init(browser)
        driver.maximize_window()
        driver.implicitly_wait(wait_time)
        driver.wait_until = lambda f, time_out=15: WebDriverWait(driver, time_out,
                                                                ignored_exceptions=(
                                                                    NoSuchElementException, ElementNotVisibleException,
                                                                    ValueError, AttributeError, WebDriverException,
                                                                    ElementNotInteractableException,
                                                                    StaleElementReferenceException,
                                                                    ElementClickInterceptedException)).until(f,
                                                                                                             "element not found on page")

        driver.click_js = lambda el, js="arguments[0].click()": driver.execute_script(js, el)
        return driver




