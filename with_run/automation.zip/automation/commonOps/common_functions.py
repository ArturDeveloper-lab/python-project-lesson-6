import time
from os.path import dirname
from random import randint
import uuid
import yaml
import boto3
import json
import os
from commonOps.actions import Actions
from ui.age_assured import pages
import json


# print(os.environ['ENVIRONMENT'])
# class Common_functions(Actions):

def load_yaml_file(filename):
    with open(dirname(dirname(__file__)) + f'/commonOps/{filename}.yaml', 'r') as f:
        doc = yaml.load(f, Loader=yaml.FullLoader)
    return doc


def read_data_from_yaml(filename, project, url_env):
    doc = load_yaml_file(filename)
    data = doc['Environment'][project][url_env]
    print(data)
    return data


def random_number(start: int, end: int):
    runNumber = randint(start, end)
    return runNumber

def refresh_page():
    time.sleep(5)
    pages.w.refresh()
    time.sleep(5)

def read_data_from_json(type:str, key:str):
    json_file = open(dirname(dirname(__file__)) + '/commonOps/data.json', 'r')
    json_data = json_file.read()
    json_obj = json.loads(json_data)
    # print(json_obj)
    # str(json_obj["user_data_type_1"]["first_name"])
    return str(json_obj[type][key])








