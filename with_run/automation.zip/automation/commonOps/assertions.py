from assertpy import assert_that
from  smart_assertions import soft_assert, verify_expectations


class Assertions:

    @staticmethod
    def assert_equals(act_param, exp_param):
        assert_that(act_param).is_equal_to(exp_param)

    @staticmethod
    def assert_equals_soft(act_param, exp_param , error_message: str ):
        soft_assert(act_param == exp_param), error_message

    @staticmethod
    def assert_contains(contained_param, exp_param):
        assert_that(contained_param).contains(exp_param)

    @staticmethod
    def assert_is_true(condition):
        assert_that(condition).is_true()

    @staticmethod
    def assert_is_true_soft(condition):
        soft_assert(condition).is_true()

    @staticmethod
    def assert_is_false(condition):
        assert_that(condition).is_false()
