from commonOps.common_functions import random_number

CONTACTS = "contacts"
BLOCK_PROGRAM_MEMBER_ASSOIATION = "Block Program Member Association"
BLOCK_PROGRAM = "Pre Menora"
FIRST_NAME = "qa"
LAST_NAME = f"Automation-{random_number(9999,99999)}"
ACCOUNT_NAME = "Menorah Ministries"
FIRSTNAME_UPDATE = "qa_update"
LASTNAME_UPDATE = "automation_update"
FULLNAME = "qa_update automation_update"
PHONENUMBER_UPDATE = "123456789"
MOBILENUMBER_UPDATE = "(052) 878-0051"
EMAIL_UPDATE = "aaa@bbb.com"
STREET_UPDATE = "Orlozorov"
CITY_UPDATE = "Tel-Aviv"
ZIPCODE_UPDATE = "77751"
CITYZIPCODE = "Tel-Aviv, 77751"
USER_INFO = {"FIRST_NAME": "Arthur",
             "LAST_NAME" :f"Automation-{random_number(9999,99999)}",
              "MIDDLE_NAME": "artur",
             "click_on_button_artur":True
            }



# Care Kickoff page text verification


# Complex Chronic Conditions - Inadherence to Care Plan Actions -finished
# ADL Bathing


# Enviroment
Assured_Allies_Placeholder = "__ASSURED_ALLIES_PLACEHOLDER__"



# Form
ADULT_CHILD = "Adult child"
ALON = "Alone"

# IADL
IADL_HOUSEKEEPING = "Yes"
IADL_MED_MGMT = "No, I receive help from a family member/friend"
IADL_NUTRITION = "No, I receive paid help"
IADL_TRANSPORTATION = "No, and I do not receive help"

# ADL
ADL_BATH = "No, and I do not receive help"
ADL_DRESS = "No, and I do not receive help"
ADL_HYGINE = "No, I receive help from a family member/friend"

# Life Engagement




# Desire to age in place
DESIRELIV = "Independent community"
BELIEFLIV = "4"
# BELIEFLIV =Likely

# Status in Program Step


# user address data




