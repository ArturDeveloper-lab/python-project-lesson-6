from page_objects import PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class Maim_page_ns(Actions):
    continue_button: WebElement = PageElement(xpath="//a[@class='next btn-lg btn-primary shadow btn']")


    def click_continue_button(self):
        # self.w.implicitly_wait(2)
        self.click(self.continue_button, 15)