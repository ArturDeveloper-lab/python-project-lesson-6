



def test_reachout_initial_status(pages,actions):
    pages.click_continue_button()