import time

from page_objects import PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class Form_onbourding_tab(Actions):

    related_from_form: WebElement = PageElement(xpath="//a[text()=\"Related\"]")
    relatedAfterClickOnForm: WebElement = PageElement(xpath="(//a[@id ='relatedListsTab__item'])[1]")
    first_risk_factor: WebElement = PageElement(xpath="(//a[@class = 'flex-wrap-ie11 slds-truncate'])[5]")
    releated_tab_in_risk_factor: WebElement = PageElement(xpath="(//a[@ id ='relatedListsTab__item'])[2]")
    risk_Factor_ADL_Dressing: WebElement = PageElement(xpath="(//span[contains(text(),'ARF-')])[6]")
    aDL_Bathing_ARF_Name_Custom: WebElement = PageElement(
        xpath="//lst-formatted-text[contains(text(),'ADL Bathing')]")
    aDL_Dressing_ARF_Name_Custom: WebElement = PageElement(
        xpath="//lst-formatted-text[contains(text(),'ADL Dressing')]")
    complex_Chronic_Conditions_ARF_Name_Custom: WebElement = PageElement(
        xpath="//lst-formatted-text[contains(text(),'Complex Chronic Conditions - Inadherence to Care Plan')]")
    risk_Factor_ADL_DressingJS: WebElement = PageElement(xpath="(//span[contains(text(),'ARF-')])[6]")
    risk_Factor_Complex_Chronic_Conditions: WebElement = PageElement(xpath="(//span[contains(text(),'ARF-')])[11]")
    relatedTab_risk_factor2: WebElement = PageElement(xpath="(//a[text()='Related'])[3]")
    relatedTab_risk_factor3: WebElement = PageElement(xpath="(//a[text()='Related'])[4]")
    resolution_name_1: WebElement = PageElement(
        xpath="//lst-formatted-text[contains(text(),'Arrange home safety evaluation')]")
    resolution_name_2: WebElement = PageElement(
        xpath="//lst-formatted-text[contains(text(),'Send assistive device')]")
    resolution_name_3: WebElement = PageElement(
        xpath="//lst-formatted-text[contains(text(),'Send vitals log and educational materials')]")
    checkBoxIsActive_resolution: WebElement = PageElement(xpath="//input[@name='isActive__c']")
    arf_form_intopBar: WebElement = PageElement(xpath="(//span[@class = 'title slds-truncate'])[3]")
    valueOf_level_of_Touch: WebElement = PageElement(xpath="(//td[normalize-space()='High'])[1]")
    formIn_Onboarding_TabJS: WebElement = PageElement(xpath="//span[@title = 'Form Name']//a")

    responder_field: WebElement = PageElement(xpath="(//lightning-formatted-text[@data-output-element-id='output-field'])[7]")
    # responder_field: WebElement = PageElement(xpath="// input[@name ='RESPONDER__c']")
    # responder_field_click: WebElement = PageElement(xpath="//label[contains(text(), 'RESPONER')]//..//..lightning-formated-text")
    livwho_field: WebElement = PageElement(xpath="(//lightning-formatted-text[@data-output-element-id= 'output-field'])[9]")
    # IADL
    iadl_housekeeping_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[8]")
    iadl_med_mgmt_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[10]")
    iadl_nutrition_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[12]")
    iadl_transportation_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[14]")
    # ADL
    adl_bath_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[15]")
    adl_dress_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[17]")
    adl_hygiene_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[19]")
    # Life Engagement
    social_family_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[24]")
    social_friends_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[26]")
    social_other_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[28]")
    social_religious_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[30]")
    social_volunteering_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[32]")
    hobbies_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[27]")
    # Health
    assistive_device_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[21]")
    health_status_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[25]")
    careplan_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[23]")
    num_medication_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[29]")
    last_visit_pcp_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[16]")
    num_falls_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[18]")
    falls_medical_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[20]")
    num_hosp_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[22]")
    # Desire to age in place
    desireliv_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[13]")
    beliefliv_field: WebElement = PageElement(xpath="(// lightning-formatted-text[@ data-output-element-id= 'output-field'])[11]")


    def go_to_releated_tab(self):
        self.click_js(self.related_from_form,15)

    def go_to_releated_tab_inside_form(self):
        self.click_js(self.relatedAfterClickOnForm, 15)

    def get_text_aDL_Bathing_ARF_Name_Custom(self):
        return str(self.get_text(self.aDL_Bathing_ARF_Name_Custom))

    def get_text_aDL_Dressing_ARF_Name_Custom(self):
        return str(self.get_text(self.aDL_Dressing_ARF_Name_Custom))

    def get_text_complex_Chronic_Conditions_ARF_Name_Custom(self):
        return str(self.get_text(self.complex_Chronic_Conditions_ARF_Name_Custom))

    def click_on_first_risk_factor(self):
        self.click_on_first_risck_factor(self.first_risk_factor,15)

    def go_to_releated_tab_in_risk_factor(self):
        self.click_on_releated_tab_risk(self.releated_tab_in_risk_factor,15)

    def get_text_resolution_name_1(self):
        return str(self.get_text(self.resolution_name_1))

    def check_is_selected_checkBoxIsActive_resolution(self):
        time.sleep(2)
        return self.is_selected(self.checkBoxIsActive_resolution, 15)

    def go_to_form_top_bar(self):
        self.click(self.arf_form_intopBar, 20)

    def go_to_risk_Factor_ADL_Dressing(self):
        self.click_js(self.risk_Factor_ADL_Dressing, 20)

    def go_to_risck_factor_2(self):
        self.click_js(self.relatedTab_risk_factor2, 20)


    def get_text_resolution_name_2(self):
        return str(self.get_text(self.resolution_name_2))

    def go_to_third_risk_factor(self):
        self.click_js(self.risk_Factor_Complex_Chronic_Conditions,20)

    def go_to_releated_tab_in_risck_factor3(self):
        self.click_js(self.relatedTab_risk_factor3,20)


    def get_text_resolution_name_3(self):
        return str(self.get_text(self.resolution_name_3))

    def get_text_valueOf_level_of_Touch(self):
        return str(self.get_text(self.valueOf_level_of_Touch))

    def get_text_responder_field(self):
        return str(self.get_text(self.responder_field))


    def get_text_responder_fieldd(self):
        time.sleep(2)
        self.click_js(self.responder_field_click, 20)
        return str(self.get_value(self.responder_field))

    def get_text_livwho_field(self):
        return str(self.get_text(self.livwho_field))

    # IADL
    def get_text_IADL_housekeeping_field(self):
        return str(self.get_text(self.iadl_housekeeping_field))

    def get_text_iadl_med_mgmt_field(self):
        return str(self.get_text(self.iadl_med_mgmt_field))


    def get_text_iadl_nutrition_field(self):
        return str(self.get_text(self.iadl_nutrition_field))

    def get_text_iadl_transportation_field(self):
        return str(self.get_text(self.iadl_transportation_field))

   #ADL
    def get_text_adl_bath_field(self):
        return str(self.get_text(self.adl_bath_field))

    def get_text_adl_dress_field(self):
        return str(self.get_text(self.adl_dress_field))

    def get_text_adl_hygiene_field(self):
        return str(self.get_text(self.adl_hygiene_field))

   #Life Engagement
    def get_text_social_family_field(self):
        return str(self.get_text(self.social_family_field))

    def get_text_social_friends_field(self):
        return str(self.get_text(self.social_friends_field))

    def get_text_social_other_field(self):
        return str(self.get_text(self.social_other_field))

    def get_text_social_religious_field(self):
        return str(self.get_text(self.social_religious_field))

    def get_text_social_volunteering_field(self):
        return str(self.get_text(self.social_volunteering_field))

    def get_text_hobbies_field(self):
        return str(self.get_text(self.hobbies_field))

    # Health
    def get_assistive_device_field(self):
        return str(self.get_text(self.assistive_device_field))

    def get_text_health_status_field(self):
        return str(self.get_text(self.health_status_field))

    def get_text_careplan_field(self):
        return str(self.get_text(self.careplan_field))

    def get_text_num_medication_field(self):
        return str(self.get_text(self.num_medication_field))

    def get_text_last_visit_pcp_field(self):
        return str(self.get_text(self.last_visit_pcp_field))

    def get_text_num_falls_field(self):
        return str(self.get_text(self.num_falls_field))

    def get_text_falls_medical_field(self):
        return str(self.get_text(self.falls_medical_field))

    def get_text_num_hosp_field(self):
        return str(self.get_text(self.num_hosp_field))

    # Desire to age in place

    def get_text_desireliv_field(self):
        return str(self.get_text(self.desireliv_field))

    def get_text_beliefliv_field(self):
        return str(self.get_text(self.beliefliv_field))

