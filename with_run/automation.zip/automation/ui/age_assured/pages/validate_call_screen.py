import time

from page_objects import PageObject, PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class ValidateCallScreen(Actions):


    YES_SPEAKINGWITHMEMBER: WebElement = PageElement(xpath="(//span[contains(text(), \"Are you speaking with the member?\")]//..//..//..//span[@class=\"slds-radio_faux\"])[1]")
    YES_VALIDATEDCALLER: WebElement = PageElement(xpath="(//span[contains(text(), \"I have validated\")]//..//..//..//span[@class=\"slds-radio_faux\"])[1]")
    YES_HasTheMemberOrContactGivenConsent: WebElement = PageElement(xpath="(//span[contains(text(), \"Has the member or contact given consent to participate in the program\")]//..//..//..//span[@class=\"slds-radio_faux\"])[1]")

    def select_all_question_yes(self):
        time.sleep(1)
        self.click_js(self.YES_SPEAKINGWITHMEMBER, 15)
        time.sleep(1)
        self.click_js(self.YES_VALIDATEDCALLER, 15)
        time.sleep(1)
        self.click_js(self.YES_HasTheMemberOrContactGivenConsent, 15)