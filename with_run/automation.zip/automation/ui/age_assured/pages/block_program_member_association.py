import time

from page_objects import PageElement, PageObject
from selenium.webdriver.remote.webelement import WebElement

from commonOps.global_text_constants import LAST_NAME, BLOCK_PROGRAM
from commonOps.actions import Actions


class BlockProgramMemberAssociation(Actions):

    creatNewBlockMemberButton:WebElement = PageElement(xpath= "(//div[@title='New'])[2]")
    blockProgram:WebElement = PageElement(xpath= "//input[@placeholder='Search Block Program...']")
    preProgram:WebElement = PageElement(xpath= "(//span[@class='slds-media__body'])[2]")
    contactsField: WebElement = PageElement(xpath="//input[@placeholder='Search Contacts...']")
    programStep: WebElement = PageElement(xpath="(//div[@class = 'slds-combobox__form-element slds-input-has-icon slds-input-has-icon_right'])[5]")
    pending: WebElement = PageElement(xpath="(//div[@class = 'slds-combobox__form-element slds-input-has-icon slds-input-has-icon_right'])[2]")
    questionnaireCompletedProgramStep: WebElement = PageElement(xpath="//span[@title='Onboarding - questionnaire completed']")
    meet_Greet_ProgramStep: WebElement = PageElement(xpath="//span[@title='Meet & Greet']")
    contactName: WebElement = PageElement(xpath="//span[contains(@title, '" +LAST_NAME + "')]")
    generalSaveEditButton: WebElement = PageElement(xpath="//button[@name='SaveEdit']")

    def create_block_program(self, time_out=20):
        time.sleep(3)
        self.click(self.creatNewBlockMemberButton, time_out)
        self.insert_text(self.blockProgram, BLOCK_PROGRAM, time_out)
        self.click(self.preProgram, time_out)
        self.click(self.contactsField, time_out)
        self.click_js(self.contactName, time_out)
        # self.click_js(self.programStep, time_out)
        # self.click_js(self.questionnaireCompletedProgramStep, time_out)
        # self.click(self.pending, time_out)
        # self.click(self.meet_Greet_ProgramStep, time_out)
        time.sleep(2)
        self.click(self.generalSaveEditButton, time_out)

