import time

from page_objects import PageObject, PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class Contact(Actions):
    firstName = ""

    newContact: WebElement = PageElement(xpath="//a[@title='New']")
    nextButtonInNewContact: WebElement = PageElement(xpath="//span[normalize-space()='Next']")
    arrowToOpenDropDownMenuInContact: WebElement = PageElement(xpath="(//span[@class='slds-icon_container slds-icon-utility-down'])[1]")
    deleteContact: WebElement = PageElement(xpath="//a[@title='Delete']")
    deleteButtonInPopup: WebElement = PageElement(xpath="//button[@title='Delete']")



    def click_newcontactbutton(self):
        time.sleep(2)
        self.click_js(self.newContact, 20)
        time.sleep(2)
        self.click_js(self.nextButtonInNewContact, 20)


    def delete_contact(self):
        time.sleep(5)
        try:
            for count in range(5):
                count += 1
                self.click(self.arrowToOpenDropDownMenuInContact, 15)
                time.sleep(2)
                self.click(self.deleteContact, 15)
                time.sleep(2)
                self.click(self.deleteButtonInPopup, 15)
                time.sleep(3)
                print("delete contact")
        except :
            print("not existing any contacts\n")


    # def create_contact(self,first_name :str,last_name:str ,account:str ,JSON):
