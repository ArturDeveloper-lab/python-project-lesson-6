import time

from page_objects import PageElement, PageObject
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class Onbourding_screen(Actions):


    respondent_type_1_1: WebElement = PageElement(xpath="(//span[contains(text(),'Meet & Greet completed?')]//..//..//..//span[@class=\"slds-radio_faux\"])[1]")
    respondent_type_2_3: WebElement = PageElement(xpath="(//span[contains(text(),'Who is answering this?')] //..//..//..// span[ @class ='slds-radio_faux'])[3]")
    respondent_type_3_1: WebElement = PageElement(xpath="(//label[@class ='slds-checkbox__label'])[1]")
    # respondent_type_3_1: WebElement = PageElement(xpath="(//span[@class ='slds-checkbox--faux'])[16]")
    life_engagement_1_1: WebElement = PageElement(xpath="(//span[contains(text(),'How often do you participate in any of the following activities: Attending religious services or religious events')] //..//..//..// span[ @class ='slds-radio_faux'])[1]")
    life_engagement_2_2: WebElement = PageElement(xpath="(//span[contains(text(),'How often do you participate in any of the following activities: Volunteering')] //..//..//..// span[ @class ='slds-radio_faux'])[2]")
    life_engagement_3_3: WebElement = PageElement(xpath="(//span[contains(text(),'How often do you participate in any of the following activities: Spending time with friends')] //..//..//..// span[ @class ='slds-radio_faux'])[3]")
    life_engagement_4_4: WebElement = PageElement(xpath="(//span[contains(text(),'How often do you participate in any of the following activities: Spending time with family')] //..//..//..// span[ @class ='slds-radio_faux'])[4]")
    life_engagement_5_5: WebElement = PageElement(xpath="(//span[contains(text(),'How often do you participate in any of the following activities: Other social activities')] //..//..//..// span[ @class ='slds-radio_faux'])[5]")
    life_engagement_6_4: WebElement = PageElement(xpath="(//span[contains(text(),'How often do you participate in any indoor or outdoor hobbies?')] //..//..//..// span[ @class ='slds-radio_faux'])[4]")
    iadls_1_1: WebElement = PageElement(xpath="(//span[contains(text(),'Are you able to perform these tasks independently? Housekeeping and home maintenance')] //..//..//..// span[ @class ='slds-radio_faux'])[1]")
    iadls_2_2: WebElement = PageElement(xpath="(//span[contains(text(),'Are you able to perform these tasks independently? Grocery shopping and meal preparation')] //..//..//..// span[ @class ='slds-radio_faux'])[2]")
    iadls_3_3: WebElement = PageElement(xpath="(//span[contains(text(),'Are you able to perform these tasks independently? Managing medications')] //..//..//..// span[ @class ='slds-radio_faux'])[3]")
    iadls_4_4: WebElement = PageElement(xpath="(//span[contains(text(),'Are you able to perform these tasks independently? Running errands and other transportation needs')] //..//..//..// span[ @class ='slds-radio_faux'])[4]")
    alds_1_4: WebElement = PageElement(xpath="(//span[contains(text(), 'Are you able to perform these tasks independently? Bathing')] //..//..//..// span[ @ class ='slds-radio_faux'])[4]")
    alds_1_2: WebElement = PageElement(xpath="(//span[contains(text(),'Are you able to perform these tasks independently? Bathing')]//..//..//..//span[@class=\"slds-radio_faux\"])[2]")
    alds_2_5: WebElement = PageElement(xpath="(//span[contains(text(),'Are you able to perform these tasks independently? Dressing')] //..//..//..// span[ @class ='slds-radio_faux'])[4]")
    alds_2_2: WebElement = PageElement(xpath="(//span[contains(text(),'Are you able to perform these tasks independently? Dressing')]//..//..//..//span[@class=\"slds-radio_faux\"])[2]")
    alds_3_3: WebElement = PageElement(xpath="(//span[contains(text(),'Are you able to perform these tasks independently? Personal hygiene (for example, brushing teeth, brushing hair, nail care, etc.)')] //..//..//..// span[ @class ='slds-radio_faux'])[3]")
    # health_1_5: WebElement = PageElement(xpath="(//span[@class ='slds-checkbox--faux'])[9]")
    health_1_5: WebElement = PageElement(xpath="(//label[@class ='slds-checkbox__label'])[9]")
    health_2_3: WebElement = PageElement(xpath="(// span[contains(text(), 'How would you rate your overall health?')] //..//..//..// span[ @class ='slds-radio_faux'])[3]")
    health_3_1: WebElement = PageElement(xpath="(//span[contains(text(),'Has your doctor and/or another clinician given you (written) formal guidance for lifestyle modifications, diet, ')] //..//..//..// span[ @class ='slds-radio_faux'])[1]")
    health_4_2: WebElement = PageElement(xpath="(//span[contains(text(),'Type of answer')] //..//..//..// span[ @class ='slds-radio_faux'])[3]")
    health_5_3: WebElement = PageElement(xpath="(//span[contains(text(),'When was the last time you visited your primary care physician?')] //..//..//..// span[ @class ='slds-radio_faux'])[3]")
    health_6_textbox: WebElement = PageElement(xpath="(//input[@class='slds-input'])[2]")
    health_7_textbox: WebElement = PageElement(xpath="(//input[@class='slds-input'])[3]")
    health_8_textbox: WebElement = PageElement(xpath="(//input[@class='slds-input'])[4]")
    # health_8_textbox: WebElement = PageElement(xpath="(//input[@class='slds-input'])[5]")
    desire_to_age_in_place_1_3: WebElement = PageElement(xpath="(//span[contains(text(),'Where do you want to live as you age?')] //..//..//..// span[ @class ='slds-radio_faux'])[3]")
    desire_to_age_in_place_2_1: WebElement = PageElement(xpath="(//span[contains(text(),'Have you finished entering questionnaire data?')]//..//..//..//span[@class=\"slds-radio_faux\"])[1]")
    desire_to_age_in_place_5_4: WebElement = PageElement(xpath="(// span[contains(text(), 'How likely do you think it is that this will happen?')] //..//..//..// span[ @class ='slds-radio_faux'])[4]")
    desire_to_age_in_place_4_textbox: WebElement = PageElement(xpath="//textarea[@class='slds-textarea']")
    # health_9_4: WebElement = PageElement(xpath="(//span[contains(text(),'How likely do you think it is that this will happen?')] //..//..//..// span[ @class ='slds-radio_faux'])[4]")



    def onbourding_question_high_resolution(self):
        self.click_js(self.respondent_type_1_1, 15)
        self.click_js(self.alds_1_2, 15)
        self.click_js(self.alds_2_2, 15)
        self.click_js(self.desire_to_age_in_place_2_1, 15)
        self.insert_text(self.desire_to_age_in_place_4_textbox, "hi to all", 15)

    def fill_all_questions(self):
        self.click_js(self.respondent_type_1_1, 15)
        self.click_js(self.respondent_type_2_3, 15)
        time.sleep(1)
        self.click_js(self.respondent_type_3_1, 15)
        self.click_js(self.life_engagement_1_1, 15)
        self.click_js(self.life_engagement_2_2, 15)
        self.click_js(self.life_engagement_3_3, 15)
        self.click_js(self.life_engagement_4_4, 15)
        self.click_js(self.life_engagement_5_5, 15)
        self.click_js(self.life_engagement_6_4, 15)

        self.click_js(self.iadls_1_1, 15)
        self.click_js(self.iadls_2_2, 15)
        self.click_js(self.iadls_3_3, 15)
        self.click_js(self.iadls_4_4, 15)

        self.click_js(self.alds_1_4, 15)
        self.click_js(self.alds_2_5, 15)
        self.click_js(self.alds_3_3, 15)


        self.click_js(self.health_1_5, 15)
        self.click_js(self.health_2_3, 15)
        self.click_js(self.health_3_1, 15)
        self.click_js(self.health_4_2, 15)
        self.click_js(self.health_5_3, 15)
        self.insert_text(self.health_6_textbox, "3", 15)
        self.insert_text(self.health_7_textbox, "2", 15)
        self.insert_text(self.health_8_textbox, "4", 15)

        self.click_js(self.desire_to_age_in_place_1_3, 15)
        self.click_js(self.desire_to_age_in_place_2_1, 15)
        self.click_js(self.desire_to_age_in_place_5_4, 15)
        self.insert_text(self.desire_to_age_in_place_4_textbox, "hi to all", 15)


    def meet_greet_finished_questionnaire(self):
        self.click_js(self.respondent_type_1_1, 15)
        self.click_js(self.desire_to_age_in_place_2_1, 15)










