import time

from page_objects import PageObject, PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class BasePage(Actions):

    nextButton : WebElement= PageElement(xpath="//button[@class='slds-button slds-button_brand flow-button__NEXT']")
    # this save button in the action execution shoul check in the other screen if the xpath is same
    save_button: WebElement = PageElement(xpath="//button[@class='slds-button slds-button_brand save-btn']")


    def click_on_next_button(self):
        time.sleep(2)
        self.click_js(self.nextButton, 20)

    def click_on_save_button(self):
        self.click(self.save_button, 20)

