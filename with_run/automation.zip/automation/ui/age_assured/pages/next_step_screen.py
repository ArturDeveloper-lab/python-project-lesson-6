from page_objects import PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class NextStepScreen(Actions):


    datePicker: WebElement  = PageElement(xpath="//lightning-datepicker[@class='slds-form-element']")
    assignToDropDownJS: WebElement = PageElement(xpath="//div[@class='slds-select_container']")
    testMVSP_Member: WebElement = PageElement(xpath="//option[text()=\"Test MVSP\"]")
    okButtonInErrorPopup: WebElement = PageElement(xpath="//button[@class='slds-button slds-button--neutral uiButton--default uiButton--neutral uiButton forceActionButton']")
    # no_follow_up: WebElement = PageElement(xpath="//span[text() = 'No follow-up is needed']")
    no_follow_up: WebElement = PageElement(xpath="(//span[@class='slds-radio_faux'])[5]")

    def no_follow_up_option(self):
        self.click_js(self.no_follow_up, 30)
   