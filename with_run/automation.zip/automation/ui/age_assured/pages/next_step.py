import time

from page_objects import PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class Next_step(Actions):

    no_follow_up_option: WebElement = PageElement(xpath="(//span[@class='slds-radio_faux'])[5]")

    def select_no_follow_up(self):
        time.sleep(7)
        self.click_js(self.no_follow_up_option,15)
        time.sleep(3)