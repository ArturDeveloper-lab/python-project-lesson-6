from page_objects import PageElement, PageObject
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class Update_member_details(Actions):


    firstNameField: WebElement = PageElement(xpath="//input[@placeholder='First Name']")
    lastNameField: WebElement = PageElement(xpath="//input[@placeholder='Last Name']")
    phoneField: WebElement = PageElement(xpath="(//input[@type='tel'])[1]")
    mobileField: WebElement = PageElement(xpath="(//input[@type='tel'])[2]")
    emailField: WebElement = PageElement(xpath="//input[@inputmode='email']")
    streetField: WebElement = PageElement(xpath="//textarea[@name='street']")
    cityField: WebElement = PageElement(xpath="//input[@name='city']")
    zipCodeField: WebElement = PageElement(xpath="//input[@name='postalCode']")

