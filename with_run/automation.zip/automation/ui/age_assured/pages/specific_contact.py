import time

from page_objects import PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class MemberObject(Actions):
    ADDBUTTONINACTIONS: WebElement = PageElement(xpath="//article/div[2]/div/div[1]/button")
    onbourdingButtonAfterClickAdd: WebElement = PageElement(xpath="//div[text()=\"Onboard member\"]")
    careKickoffButtonAfterClickAdd: WebElement = PageElement(xpath="//div[text()='Care Kickoff']")
    action_execution_button_after_click_add: WebElement = PageElement(xpath="//div[text()='Action Execution']")
    updateMemberDetailsButton: WebElement = PageElement(xpath="//div[text()='Update member details']")
    pendingNA: WebElement = PageElement(xpath="//span[text()=\"Pending\"]//..//..//span[text()=\"N/A\"]")
    nextTouchpoint: WebElement = PageElement(
        xpath="//span[text()=\"Next touchpoint\"]//..//..//span[contains(text(), \"11/10/2021\")]")
    assignedToAlly: WebElement = PageElement(xpath="//a[text()=\"Test MVSP\"]")
    actionsOptions: WebElement = PageElement(xpath="(//a[text()=\"Actions\"])[1]")
    onboarding: WebElement = PageElement(xpath="(//a[text()=\"Onboarding\"])[1]")
    deleteButton: WebElement = PageElement(xpath="//button[text()='Delete']")
    deleteButtonInPopup: WebElement = PageElement(xpath="//button[@title='Delete']")
    contactFullNameInMemberObject: WebElement = PageElement(xpath="//span[@class='custom-truncate uiOutputText']")
    SummarySection: WebElement = PageElement(xpath="//span[@title='Summary']")
    contactInformationSection: WebElement = PageElement(xpath="(//span[@title='Contact Information'])[1]")
    detailsMemberObjectWithoutTab: WebElement = PageElement(xpath="//a[text()=\"Details\"]")
    phoneContactInformation: WebElement = PageElement(xpath="(//span[@dir='ltr'])[2]")
    emailContactInformation: WebElement = PageElement(xpath="//a[@class='emailuiFormattedEmail']")
    streetContactInformation: WebElement = PageElement(
        xpath="(//div[@class='slds-truncate forceOutputAddressText'])[1]")
    cityZipCodeContactInformation: WebElement = PageElement(
        xpath="(//div[@class='slds-truncate forceOutputAddressText'])[2]")
    mobilePhoneContactInformation: WebElement = PageElement(xpath="(//span[@dir='ltr'])[3]")
    memberData: WebElement = PageElement(xpath="//a[text()=\"Member\"]")
    # programStep_status: WebElement = PageElement(xpath="//span[text()=\"Onboarding - questionnaire completed\"]")
    activeStatus: WebElement = PageElement(xpath="//pan[text() = 'Active']")
    program_step: WebElement = PageElement(xpath="(//span[contains(text(),'Program Step')]//..//..//span[contains(@class, 'is-read-only')]/span)[1]")



    def go_actions_section(self):
        time.sleep(5)
        self.click(self.actionsOptions, 20)
        time.sleep(40)
        self.click_js(self.ADDBUTTONINACTIONS, 140)

    def onbourding_section(self):
        time.sleep(2)
        self.click(self.onbourdingButtonAfterClickAdd, 10)

    def care_cikof_section(self):
        time.sleep(3)
        self.click(self.careKickoffButtonAfterClickAdd, 20)

    def action_execution_section(self):
        time.sleep(5)
        self.click_js(self.action_execution_button_after_click_add, 20)

    def go_to_member(self):
        time.sleep(2)
        self.click(self.memberData, 15)

    def check_existig_na(self):
        # return self.pendingNA.is_displayed()
        return self.is_displayed(self.pendingNA, 15)

    # def check_existig_programstep(self):
    #     # return self.programStep_status.is_displayed()
    #     return self.is_displayed(self.programStep_status, 15)

    def get_text_program_step(self):
        return str(self.get_text(self.program_step))

    def go_to_member_detals(self):
        time.sleep(2)
        self.click_js(self.detailsMemberObjectWithoutTab, 15)

    def delete_block_program(self):
        time.sleep(5)
        self.click_js(self.deleteButton, 20)
        self.click_js(self.deleteButtonInPopup, 15)
        time.sleep(2)

    def go_to_onbourding_tab(self):
        time.sleep(6)
        self.click(self.onboarding, 20)

    # def get_text_program_step(self):
    #     return str(self.get_text(self.program_step))







