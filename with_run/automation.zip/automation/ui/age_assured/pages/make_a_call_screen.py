import time

from page_objects import PageObject, PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class MakeACallScreen(Actions):


    yess_Are_you_starting_a_call: WebElement  = PageElement(xpath="(//span[contains(text(),'Are you starting a call')]//..//..//..//span[@class='slds-radio_faux'])[1]")
    selectForm: WebElement = PageElement(xpath="//span[@class='slds-radio_faux']")

    def select_form(self):
        time.sleep(3)
        self.click_js(self.selectForm,15)
   