from page_objects import PageElement, PageObject
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions
from ui.age_assured.pages.base_page import BasePage


class LoginPage(Actions):

    USERNAME_FIELD: WebElement = PageElement(id_='username')
    PASSWORD_FIELD: WebElement = PageElement(id_='password')
    LOGIN_BTN: WebElement = PageElement(id_='Login')



    def login(self, username, password, time_out: int = 15):
        self.insert_text(self.USERNAME_FIELD, username, time_out)
        self.insert_text(self.PASSWORD_FIELD, password, time_out)
        self.click(self.LOGIN_BTN, time_out)


    # def login(self, username, password, time_out: int = 15):
    #     self.insert_text(self.USERNAME_FIELD, username, time_out)
    #     self.insert_text(self.PASSWORD_FIELD, password, time_out)
    #     self.click(self.LOGIN_BTN, time_out)
    #     self.click(self.LOGIN_BTN, time_out)






