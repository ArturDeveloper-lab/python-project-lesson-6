import time

from page_objects import PageObject, PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.global_text_constants import FIRST_NAME, LAST_NAME, ACCOUNT_NAME
from commonOps.actions import Actions


class NewContact_New_Policy_Holder(Actions):
    def __init__(self, driver):
        super().__init__(driver)
        self.first_name: WebElement = PageElement(xpath="//input[@placeholder='First Name']")
        self.lastName: WebElement = PageElement(xpath="//input[@placeholder='Last Name']")
        self.middle_name: WebElement = PageElement(xpath="//input[ @ placeholder = 'Middle Name']")
        self.accountField: WebElement = PageElement(xpath="// input[@placeholder = 'Search Accounts...']")
        self.nameOfAcountInField: WebElement = PageElement(xpath="(//span[@class='slds-media__body'])[2]")
        # self.accountNameField: WebElement = PageElement(xpath="//input[@placeholder='Search Accounts...']")
        self.saveButton: WebElement = PageElement(xpath="//button[@name='SaveEdit']")
        self.mailing_street = PageElement(xpath="(//textarea[@class ='slds-textarea'])[1]")



        self.user_data = {"first_name": [self.first_name, FIRST_NAME],
                     "last_name": [self.lastName, LAST_NAME],
                     "middle_name": [self.middle_name, LAST_NAME]}



    def click_search_accounts(self):
        self.click_specific_js(self.accountField, 2)



    def create_user_data(self ,**kwargs):
        time.sleep(2)
        for kwarg in kwargs:
            kwarg_dict = self.user_data.get(kwarg, None)
            if kwarg_dict is None:
                continue
            self.insert_text(self.user_data[kwarg][0], self.user_data[kwarg][1], 15)
        # if first_name:
        #     self.insert_text(self.first_name, FIRST_NAME, 15)
        # time.sleep(2)
        # if last_name:
        #     self.insert_text(self.lastName, LAST_NAME, 15)
        # if middle_name:
        #     self.click_specific_js(self.accountField, 15)



        time.sleep(2)
        self.insert_text(self.accountField, ACCOUNT_NAME, 15)
        time.sleep(5)
        self.click_js(self.nameOfAcountInField, 15)
        time.sleep(3)
        self.click_js(self.saveButton, 15)

    # def create_user_data(self, first_name: str = None, last_name: str = None, middle_name: str = None):
    #     time.sleep(2)
    #     if first_name:
    #         self.insert_text(self.first_name, FIRST_NAME, 15)
    #     time.sleep(2)
    #     if last_name:
    #         self.insert_text(self.lastName, LAST_NAME, 15)
    #     if middle_name:
    #         self.click_specific_js(self.accountField, 15)
    #     time.sleep(2)
    #     self.insert_text(self.accountField, ACCOUNT_NAME, 15)
    #     time.sleep(5)
    #     self.click_js(self.nameOfAcountInField, 15)
    #     time.sleep(3)
    #     self.click_js(self.saveButton, 15)


    # def create_user_data(self):
    #     time.sleep(2)
    #     self.insert_text(self.first_name, FIRST_NAME, 15)
    #     time.sleep(2)
    #     self.insert_text(self.lastName, LAST_NAME, 15)
    #     self.click_specific_js(self.accountField, 15)
    #     time.sleep(2)
    #     self.insert_text(self.accountField, ACCOUNT_NAME, 15)
    #     time.sleep(5)
    #     self.click_js(self.nameOfAcountInField, 15)
    #     time.sleep(3)
    #     self.click_js(self.saveButton, 15)
