import time

from page_objects import PageObject, PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class Onboardingtab(Actions):


    form_questeniers: WebElement = PageElement(xpath="//span[ @ title = 'Form Name']//a")



    def go_to_form(self):
        self.click_js(self.form_questeniers, 15)




