import time

from page_objects import PageObject, PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.global_text_constants import LAST_NAME, CONTACTS, BLOCK_PROGRAM_MEMBER_ASSOIATION
from commonOps.actions import Actions


class MainPage(Actions):
    nameOfMember: WebElement = PageElement(xpath="//a[contains(text(), '" + LAST_NAME + "')]")
    appLancher: WebElement = PageElement(xpath="//div[@class='slds-icon-waffle']")
    searchFieldAppLancher: WebElement = PageElement(xpath="//one-app-launcher-search-bar/lightning-input/div/input")
    blockProgramMemberAssociationSearchField: WebElement = PageElement(xpath="//b[contains(text(),'Block Program Member Association')]")
    arrowChengeModeInTopBur: WebElement = PageElement(xpath="//button[@title='Show Navigation Menu']")
    homeModeInsideDropDown: WebElement = PageElement(xpath="//a[@class='menuItem']//span[text()='Home']")
    contactsInsideDropDown: WebElement = PageElement(xpath="//a[@class='menuItem']//span[text()='Contacts']")
    contacts: WebElement = PageElement(xpath="//b[normalize-space()='Contacts']")
    xCloseTab: WebElement = PageElement(xpath="(//button[contains(@title,'Close')])[1]")

    def closeTabs(self):
        time.sleep(3)
        try:
            for count in range(15):
                count += 1
                self.w.wait_until(lambda f: self.xCloseTab.click())
        except:
            print("not existing the open tabs\n")

    def clickApplancher(self):
        self.click(self.appLancher, 2)

    def go_to_contacts(self):
        time.sleep(3)
        self.click(self.appLancher, 5)
        time.sleep(3)
        self.insert_text(self.searchFieldAppLancher, CONTACTS, 5)
        self.click(self.contacts, 2)

    def got_to_block_program_member_association(self):
        time.sleep(15)
        self.click_js(self.appLancher, 20)
        time.sleep(20)
        self.insert_text(self.searchFieldAppLancher, BLOCK_PROGRAM_MEMBER_ASSOIATION, 30)
        time.sleep(5)
        self.click(self.blockProgramMemberAssociationSearchField, 20)

    def go_to_compain(self):
        time.sleep(5)
        self.click(self.appLancher, 5)
        self.insert_text(self.searchFieldAppLancher, CONTACTS, 5)
        self.click(self.contacts, 2)

    def go_to_home(self):
        self.click(self.arrowChengeModeInTopBur, 15)
        time.sleep(2)
        self.click(self.homeModeInsideDropDown, 15)

    def go_to_contact(self):
        time.sleep(3)
        self.click(self.arrowChengeModeInTopBur, 15)
        time.sleep(2)
        self.click(self.contactsInsideDropDown, 15)

    def go_to_created_member(self):
        self.click_js(self.nameOfMember, 15)






