import time

from page_objects import PageObject, PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class CareKickoffPage(Actions):

    checkBox_aDL_Bathing:WebElement = PageElement(xpath= "//input[@name ='ADL_Bathing_ARF_Active']")
    checkBox_aDL_Dressing: WebElement = PageElement(xpath="//input[@name ='ADL_Dressing_ARF_Active']")
    aDL_Bathing: WebElement = PageElement(xpath="//span[contains(text(),'ADL Bathing')]")
    aDL_Dressing: WebElement = PageElement(xpath="//span[contains(text(),'ADL Dressing')]")
    dark_blue_complex_Chronic_Conditions: WebElement = PageElement(xpath="//b[contains(text(),'Complex Chronic Conditions - Inadherence to Care Plan')]")
    question_Do_you_have_a_care_plan_from_your_doctor: WebElement = PageElement(xpath="//span[contains(text(),'Do you have a care plan from your doctor(s)? This may include: prescription medications, routine checkups, lifestyle recommendations.')]")
    complex_Chronic_ConditionsJS: WebElement = PageElement(xpath="(//span[contains(text(), \"Complex Chronic Conditions - Inadherence to Care Plan\")]//..//..//..//span[@class=\"slds-checkbox_faux\"])[1]")
    text_box_ofreason_adding_ARF: WebElement = PageElement(xpath="(//textarea[@class = 'slds-textarea'])[1]")
    complex_Chronic_action_send_vitals_log :WebElement = PageElement(xpath="(//span[contains(text(), \"Send vitals log and educational materials\")]//..//..//..//span[@class=\"slds-checkbox_faux\"])[1]")
    complex_Chronic_actions_title :WebElement = PageElement(xpath="//u[contains(text(),'Complex Chronic Conditions - Inadherence to Care Plan Actions')]")
    send_vitals_log_action: WebElement = PageElement(xpath="//span[contains(text(),'Send vitals log and educational materials')]")
    send_vitals_equipment_action: WebElement = PageElement(xpath="//span[contains(text(),'Send vitals equipment, logs, and educational materials')]")
    send_med_logs_and_educational_action:WebElement = PageElement(xpath="//span[contains(text(),'Send med logs and educational materials')]")
    set_up_of_Pillpack_action:WebElement = PageElement(xpath="//span[contains(text(),'Set up of Pillpack / MedMinder')]")
    set_up_of_med_delivery_action:WebElement = PageElement(xpath="//span[contains(text(),'Set up of med delivery/presorted med')]")
    set_up_member_with_local_action:WebElement = PageElement(xpath="//span[contains(text(),'Set up member with local transportation options')]")
    set_up_ride_sharing_action:WebElement = PageElement(xpath="//span[contains(text(),'Set up ride sharing service')]")
    set_up_GOGO_account_action:WebElement = PageElement(xpath="//span[contains(text(),'Set up GOGO account for ride share')]")
    arrange_home_safety_action:WebElement = PageElement(xpath="(//span[contains(text(),'Arrange home safety evaluation')])[1]")
    send_assistive_device_action:WebElement = PageElement(xpath="(//span[contains(text(),'Send assistive device')])[1]")
    arrange_home_modification_action:WebElement = PageElement(xpath="(//span[contains(text(),'Arrange home modification')])[1]")
    arrange_home_modification_Action:WebElement = PageElement(xpath="(//span[contains(text(), \"Arrange home safety evaluation\")]//..//..//..//span[@class=\"slds-checkbox_faux\"])[1]")
    aDL_Dressing_actions_darkBlue_title:WebElement = PageElement(xpath="//b[contains(text(),'ADL Dressing')]")
    aDL_Dressing_question_What_is_difficult:WebElement = PageElement(xpath="//span[contains(text(),'What is difficult about dressing?')]")
    arrange_home_safety_Dressing_action:WebElement = PageElement(xpath="(//span[contains(text(),'Arrange home safety evaluation')])[1]")
    send_assistive_device_Dressing_action:WebElement = PageElement(xpath="(//span[contains(text(),'Send assistive device')])[1]")
    send_assistive_device_Dressing_Action:WebElement = PageElement(xpath="(//span[contains(text(), \"Send assistive device\")]//..//..//..//span[@class=\"slds-checkbox_faux\"])[2]")
    textBoxInsertText_carekicof:WebElement = PageElement(xpath="(//textarea[@class='slds-textarea'])[10]")
    yes_is_the_care_kickoff_call_complete:WebElement = PageElement(xpath="(//span[contains(text(), \"Yes\")]//..//..//..//span[@class=\"slds-radio_faux\"])[31]")
    yes_is_the_care_kickoff_call_complete_without_select:WebElement = PageElement(xpath="(//span[contains(text(), 'Yes')] //..//..//..// span[ @class ='slds-radio_faux'])[15]")
    no_is_the_care_kickoff_call_complete: WebElement = PageElement(xpath="(//span[@class ='slds-radio_faux'])[105]")
    no_is_the_care_kickoff_call_complete_without_selection: WebElement = PageElement(xpath="(// span[contains(text(), 'No')] //..//..//..// span[ @class ='slds-radio_faux'])[15]")



    def check_is_selected_checkBox_aDL_Bathing(self):
        time.sleep(2)
        return self.is_selected(self.checkBox_aDL_Bathing, 15)

    def check_is_selected_checkBox_aDL_Dressing(self):
        time.sleep(2)
        return self.is_selected(self.checkBox_aDL_Dressing, 15)

    def get_text_from_ADL_Bathing(self):
        return str(self.get_text(self.aDL_Bathing))

    def get_text_from_aDL_Dressing(self):
        return str(self.get_text(self.aDL_Dressing))

    def select_complex_chronic(self):
        self.click_js(self.complex_Chronic_ConditionsJS, 15)
        self.insert_text(self.text_box_ofreason_adding_ARF, "Best selection", 15)

    def get_text_dark_blue_complex_Chronic_Conditions(self):
        return str(self.get_text(self.dark_blue_complex_Chronic_Conditions))

    def get_text_question_Do_you_have_a_care_plan_from_your_doctor(self):
        return str(self.get_text(self.question_Do_you_have_a_care_plan_from_your_doctor))

    def select_complex_Chronic_action_send_vitals(self):
        self.click_js(self.complex_Chronic_action_send_vitals_log, 15)

    def get_text_complex_Chronic_actions_title(self):
        return str(self.get_text(self.complex_Chronic_actions_title))

    def get_text_send_vitals_log_action(self):
        return str(self.get_text(self.send_vitals_log_action))

    def get_text_send_vitals_equipment_action(self):
        return str(self.get_text(self.send_vitals_equipment_action))

    def get_text_send_med_logs_and_educational_action(self):
        return str(self.get_text(self.send_med_logs_and_educational_action))

    def get_text_set_up_of_Pillpack_action(self):
        return str(self.get_text(self.set_up_of_Pillpack_action))

    def get_text_set_up_of_med_delivery_action(self):
        return str(self.get_text(self.set_up_of_med_delivery_action))

    def get_text_set_up_member_with_local_action(self):
        return str(self.get_text(self.set_up_member_with_local_action))

    def get_text_set_up_ride_sharing_action(self):
        return str(self.get_text(self.set_up_ride_sharing_action))

    def get_text_set_up_GOGO_account_action(self):
        return str(self.get_text(self.set_up_GOGO_account_action))

    def get_text_arrange_home_safety_action(self):
        return str(self.get_text(self.arrange_home_safety_action))

    def get_text_send_assistive_device_action(self):
        return str(self.get_text(self.send_assistive_device_action))

    def get_text_arrange_home_modification_action(self):
        return str(self.get_text(self.arrange_home_modification_action))

    def select_action_Arrange_home_modification(self):
        self.click_js(self.arrange_home_modification_Action, 15)

    def get_text_aDL_Dressing_actions_darkBlue_title(self):
        return str(self.get_text(self.aDL_Dressing_actions_darkBlue_title))

    def get_text_aDL_Dressing_question_What_is_difficult(self):
        return str(self.get_text(self.aDL_Dressing_question_What_is_difficult))

    def get_text_arrange_home_safety_Dressing_action(self):
        return str(self.get_text(self.arrange_home_safety_Dressing_action))

    def get_text_send_assistive_device_Dressing_action(self):
        return str(self.get_text(self.send_assistive_device_Dressing_action))

    def select_action_send_assistive_device(self):
        self.click_js(self.send_assistive_device_Dressing_Action, 15)

    def insert_text_in_text_box_carkicof(self):
        self.insert_text(self.textBoxInsertText_carekicof, "Care kickoff automation test", 15)

    def select_yes_carkicof_compleate_call(self):
        self.click_js(self.yes_is_the_care_kickoff_call_complete, 15)


    def select_yes_carkicof_compleate_call_without_any_selection(self):
        self.click_js(self.yes_is_the_care_kickoff_call_complete_without_select, 15)


    def select_no_carkicof_compleate_call_without_any_selection(self):
        self.click_js(self.no_is_the_care_kickoff_call_complete_without_selection, 15)


    def select_no_carkicof_compleate_call(self):
        self.click_js(self.no_is_the_care_kickoff_call_complete, 15)
