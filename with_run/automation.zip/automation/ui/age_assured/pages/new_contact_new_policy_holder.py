import time

from page_objects import PageObject, PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.global_text_constants import FIRST_NAME, LAST_NAME, ACCOUNT_NAME, USER_INFO
from commonOps.actions import Actions
from commonOps import global_text_constants as text_constant


class NewContact_New_Policy_Holder(Actions):
    first_name: WebElement = PageElement(xpath="//input[@placeholder='First Name']")
    last_Name: WebElement = PageElement(xpath="//input[@placeholder='Last Name']")
    middle_name: WebElement = PageElement(xpath="//input[@placeholder='Middle Name']")


    accountField: WebElement = PageElement(xpath="// input[@placeholder = 'Search Accounts...']")
    nameOfAcountInField: WebElement = PageElement(xpath="(//span[@class='slds-media__body'])[2]")
    accountNameField: WebElement = PageElement(xpath="//input[@placeholder='Search Accounts...']")
    saveButton: WebElement = PageElement(xpath="//button[@name='SaveEdit']")
    mailing_street = PageElement(xpath="(//textarea[@class ='slds-textarea'])[1]")



    def creaute_user_data(self,**kwargs):
        time.sleep(2)
        if "FIRST_NAME" in kwargs:
            self.insert_text(self.first_name, kwargs['FIRST_NAME'], 15)
        time.sleep(2)
        if "LAST_NAME" in kwargs:
            self.insert_text(self.last_Name, kwargs['LAST_NAME'], 15)
        if "MIDDLE_NAME" in kwargs:
            self.insert_text(self.last_Name, kwargs['MIDDLE_NAME'], 15)
        self.click_specific_js(self.accountField, 15)
        time.sleep(2)
        self.insert_text(self.accountField, ACCOUNT_NAME, 15)
        time.sleep(5)
        self.click_js(self.nameOfAcountInField, 15)
        time.sleep(3)
        self.click_js(self.saveButton, 15)


    def creaute_user_data_init(self):
        self.creaute_user_data(text_constant)

    # field_name_to_web_element = {'CONTACT_FIRST_NAME': first_name,
    #                              'CONTACT_LAST_NAME': last_Name,
    #                              'CONTACT_MIDDLE_NAME': middle_name,
    #                              }
    #
    #
    def click_search_accounts(self):
        self.click_specific_js(self.accountField, 2)
    #
    # def create_user_data(self, contact_field_to_value):
    #     for field, value in contact_field_to_value.items():
    #         web_element = self.field_name_to_web_element[field]
    #         self.insert_text(self.web_element, value, 15)
    #         time.sleep(2)
    #     # self.insert_text(self.firstName, FIRST_NAME, 15)
    #     # time.sleep(2)
    #     # self.insert_text(self.lastName, LAST_NAME, 15)
    #     self.click_specific_js(self.accountField, 15)
    #     time.sleep(2)
    #     self.insert_text(self.accountField, ACCOUNT_NAME, 15)
    #     time.sleep(5)
    #     self.click_js(self.nameOfAcountInField, 15)
    #     time.sleep(3)
    #     self.click_js(self.saveButton, 15)

    # def create_user_data(self, first_name: str = None,last_name:str=None, middle_name: str = None, ):
    #     time.sleep(2)
    #     if first_name:
    #         self.insert_text(self.first_name, FIRST_NAME, 15)
    #     time.sleep(2)
    #     if last_name:
    #         self.insert_text(self.lastName, LAST_NAME, 15)
    #     if middle_name:
    #         self.insert_text(self.middle_name, "artik", 15)
    #     self.click_specific_js(self.accountField, 15)
    #     time.sleep(2)
    #     self.insert_text(self.accountField, ACCOUNT_NAME, 15)
    #     time.sleep(5)
    #     self.click_js(self.nameOfAcountInField, 15)
    #     time.sleep(3)
    #     self.click_js(self.saveButton, 15)

    # def create_user_data(self):
    #     time.sleep(2)
    #     self.insert_text(self.firstName, FIRST_NAME, 15)
    #     time.sleep(2)
    #     self.insert_text(self.lastName, LAST_NAME, 15)
    #     self.click_specific_js(self.accountField, 15)
    #     time.sleep(2)
    #     self.insert_text(self.accountField, ACCOUNT_NAME, 15)
    #     time.sleep(5)
    #     self.click_js(self.nameOfAcountInField, 15)
    #     time.sleep(3)
    #     self.click_js(self.saveButton, 15)

    # def creaute_user_data_with_address(self, first_name: str, last_name: str, account_name: str):
    #     time.sleep(2)
    #     self.insert_text(self.firstName, FIRST_NAME, 15)
    #     time.sleep(2)
    #     self.insert_text(self.lastName, LAST_NAME, 15)
    #     self.click_specific_js(self.accountField, 15)
    #     time.sleep(2)
    #     self.insert_text(self.accountField, ACCOUNT_NAME, 15)
    #     time.sleep(5)
    #     self.click_js(self.nameOfAcountInField, 15)
    #     time.sleep(3)
    #     self.click_js(self.saveButton, 15)
