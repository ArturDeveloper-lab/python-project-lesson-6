import time

from page_objects import PageElement
from selenium.webdriver.remote.webelement import WebElement

from commonOps.actions import Actions


class Action_execution(Actions):



    action_staus_fild_1: WebElement = PageElement(xpath="//body[1]/div[4]/div[1]/section[1]/div[1]/div[1]/div[2]/div[2]/section[1]/div[1]/div[1]/section[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/flowruntime-lwc-body[1]/div[1]/flowruntime-list-container[1]/div[1]/flowruntime-screen-field[3]/flowruntime-list-container[1]/div[1]/flowruntime-screen-field[2]/flowruntime-list-container[1]/div[1]/flowruntime-screen-field[2]/flowruntime-lwc-field[1]/div[1]/c-datatable[1]/div[1]/div[1]/c-ers_custom-lightning-datatable[1]/div[2]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[3]/lightning-primitive-cell-factory[1]/div[1]/lightning-primitive-custom-cell[1]/c-ers_combobox-column-type[1]/div[1]")
    action_staus_fild_2: WebElement = PageElement(xpath="(// div[@class = 'combobox-view__min-height cell__is-editable slds-grid slds-p-vertical_xx-small slds-p-horizontal_x-small slds-var-m-around_xxx-small'])[1]")
    action_staus_fild_3: WebElement = PageElement(xpath="(// div[@class ='slds-hyphenate'])[1]")




    pen: WebElement = PageElement(xpath="(//button[@class = 'slds-button slds-button_icon slds-button_icon-bare'])[2]")
    action_staus_fild_button: WebElement = PageElement(xpath="(// button[@class = 'slds-combobox__input slds-input_faux slds-combobox__input-value'])[1]")
    approved_by_member: WebElement = PageElement(xpath="// span[ @ title = 'Approved by member/caregiver']")



    def go_to_select_action_status(self):
        print("click on the filed 1 in action status")
        time.sleep(5)
        # self.click_js(self.action_staus_fild_1, 20)
        #             self.click_js(self.action_staus_fild_1, 20)
        # goood
        # self.click_js(self.action_staus_fild_2, 20)
        # good
        self.click(self.action_staus_fild_3, 20)

        time.sleep(3)
        print("click on the pen")
        self.click_js(self.pen, 20)
        # self.click(self.pen, 20)
        print("Click on the field after clicked on the pen")
        self.click(self.action_staus_fild_button, 20)
        print("The action status selected")

    def select_action_status(self):
        self.click(self.approved_by_member,15)
