import time

import allure
from assertpy import assert_that
from smart_assertions import soft_assert, verify_expectations

from commonOps.global_text_constants import ADL_BATHING, ADL_DRESSING, COMPLEX_CHRONIC, QUESTION_COMPLEX_CHRONIC, \
    COMPLEX_CHRONIC_CONDITIONS_TITLE, SEND_VITALS_LOG_ACTION, SEND_VITALS_EQUIPMENT_ACTION, SEND_MED_LOGS_ACTION, \
    SET_UP_OF_PILLPACK_ACTION, SET_UP_OF_MED_DELIVERY_ACTION, SET_UP_MEMBER_ACTION, SET_UP_RIDE_ACTION, \
    SET_UP_GOGO_ACTION, ARRANGE_HOME_SAFETY_ACTION, SEND_ASSISTIVE_DEVICE_ACTION, ARRANGE_HOME_MODIFICATION_ACTION, \
    ADL_DRESSING_QUESTION_WHAT_IS_DIFFICULT, ARRANGE_HOME_SAFETY_DRESSING_ACTION, SEND_ASSISTIVE_DEVICE_DRESSING_ACTION, \
    VALUEOF_LEVEL_OF_TOUCH, COMPLEX_CHRONIC_CONDITIONS_ARF_NAME_CUSTOM, RESOLUTIONNAME_1, RESOLUTIONNAME_2, \
    RESOLUTIONNAME_3, ADULT_CHILD, ALON, IADL_HOUSEKEEPING, IADL_MED_MGMT, IADL_NUTRITION, IADL_TRANSPORTATION, \
    ADL_BATH, ADL_DRESS, ADL_HYGINE, SOCIAL_FAMILY, SOCIAL_FRIENDS, SOCIAL_OTHER, SOCIAL_religious, SOCIAL_volunteering, \
    HOBBIES, ASSISTIVE_DEVICE, HEALTH_STATUS, CAREPLAN, NUM_MEDICATION, LAST_VISIT_PCP, NUM_FALLS, FALLS_MEDICAL, \
    NUM_HOSP, DESIRELIV, BELIEFLIV, QUESTONNAIRE_COMLETED, REACHOUT_INITIAL, CARE_PASSIVE, CARE_CHECKIN, \
    CARE_KICKOFF_IN_PROCESS, CARE_KICKOF_AWAITING_CARE_PLAN_REVIEW, CARE_ACTIVE_ACTION, FIRST_NAME, LAST_NAME, \
    ACCOUNT_NAME
from commonOps.common_functions import connect_to_secret_maneger, read_data_from_json, random_number

user_name = connect_to_secret_maneger("user_name")
password = connect_to_secret_maneger("password")




# """
# Checked status of  "reachout_initial"
# Create member
# """
# @allure.description("When a member is added to SF")
# def test_reachout_initial_status(pages, general_flow, actions, assertion):
#     pages.login(user_name, password)
#     print("login finished")
#     pages.closeTabs()
#
#     sf_object_to_fields = {'Contact':
#         {
#             'CONTACT_FIRST_NAME': 'Ruth',
#             'CONTACT_LAST_NAME': 'Yarus'
#         }
#     }
#
#     general_flow.create_member(sf_object_to_fields)
#     # general_flow.create_member()
#     pages.go_to_created_member()
#     print("clicked on the created member in home screen")
#     time.sleep(3)
#     assert_that(REACHOUT_INITIAL).is_equal_to(pages.get_text_program_step())
#     pages.go_to_member_detals()
#     pages.delete_block_program()
#     print("delete block program of member")
#     pages.go_to_contact()
#     pages.delete_contact()
#     print("delete all contacts")

"""
Checked status of  "reachout_initial"
Create member
"""


@allure.description("When a member is added to SF")
def test_reachout_initial_status(pages, general_flow, actions, assertion):
    pages.login(user_name, password)
    print("login finished")
    pages.closeTabs()
    general_flow.create_member("first_name","last_name","middle_name")
    pages.go_to_created_member()
    print("clicked on the created member in home screen")
    time.sleep(3)
    assert_that(REACHOUT_INITIAL).is_equal_to(pages.get_text_program_step())
    pages.go_to_member_detals()
    pages.delete_block_program()
    print("delete block program of member")
    pages.go_to_contact()
    pages.delete_contact()
    print("delete all contacts")

# """
# Checked status of  "reachout_initial"
# Create member
# """
#
#
# @allure.description("When a member is added to SF")
# def test_reachout_initial_status(pages, general_flow, actions, assertion):
#     pages.login(user_name, password)
#     print("login finished")
#     pages.closeTabs()
#     general_flow.create_member("first_name","last_name","middle_name")
#     pages.go_to_created_member()
#     print("clicked on the created member in home screen")
#     time.sleep(3)
#     assert_that(REACHOUT_INITIAL).is_equal_to(pages.get_text_program_step())
#     pages.go_to_member_detals()
#     pages.delete_block_program()
#     print("delete block program of member")
#     pages.go_to_contact()
#     pages.delete_contact()
#     print("delete all contacts")


"""
Checked status of  "Onboarding - questionnaire completed"
In the meet and greet select Yes
select questions with high

Create member
"""


@allure.description("When an ally mark the questionnaire as completed in an online flow with Meet and Greet")
def test_onbourding_questionnaire_completed_meet_and_greet(pages, general_flow, actions, assertion):
    pages.login(user_name, password)
    print("login finished")
    pages.closeTabs()
    general_flow.create_member()
    pages.go_to_created_member()
    print("clicked on the created member in home screen")
    pages.go_actions_section()
    print("click on the add button to display all section of functionality")
    pages.onbourding_section()
    print("select onbourding")
    pages.click_on_next_button()
    pages.select_all_question_yes()
    pages.click_on_next_button()
    pages.onbourding_question_high_resolution()
    time.sleep(2)
    pages.click_on_next_button()
    time.sleep(3)
    pages.select_no_follow_up()
    time.sleep(2)
    pages.click_on_next_button()
    pages.go_to_member()
    print("click on the member after onbourding process")
    time.sleep(3)
    assert_that(QUESTONNAIRE_COMLETED).is_equal_to(pages.get_text_program_step())
    pages.go_to_member_detals()
    pages.delete_block_program()
    print("delete block program of member")
    pages.go_to_contact()
    pages.delete_contact()
    print("delete all contacts")


@allure.description(
    "When an ally mark all questionnaire's questions as completed in an online flow with Meet and Greet")
def test_onbourding_fill_all_questions(pages, general_flow, actions, assertion):
    pages.login(user_name, password)
    print("login finished")
    pages.closeTabs()
    general_flow.create_member()
    pages.go_to_created_member()
    print("click on the created member in home screen")
    pages.go_actions_section()
    print("click on the add button to display all section of functionality")
    pages.onbourding_section()
    print("select onbourding")
    pages.click_on_next_button()
    pages.select_all_question_yes()
    pages.click_on_next_button()
    time.sleep(3)
    pages.fill_all_questions()
    pages.click_on_next_button()
    time.sleep(3)
    pages.select_no_follow_up()
    pages.click_on_next_button()
    time.sleep(3)
    pages.go_to_onbourding_tab()
    pages.go_to_form()
    soft_assert(pages.get_text_responder_field() == ADULT_CHILD,
                f"The actual-  {pages.get_text_responder_field()} value not much to the expected value- {ADULT_CHILD}")
    soft_assert(pages.get_text_livwho_field() == ALON,
                f"The actual-  {pages.get_text_livwho_field()} value not much to the expected value- {ALON}")
    soft_assert(pages.get_text_IADL_housekeeping_field() == IADL_HOUSEKEEPING,
                f"The actual-  {pages.get_text_IADL_housekeeping_field()} value not much to the expected value- {IADL_HOUSEKEEPING}")
    soft_assert(pages.get_text_iadl_med_mgmt_field() == IADL_MED_MGMT,
                f"The actual-  {pages.get_text_iadl_med_mgmt_field()} value not much to the expected value- {IADL_MED_MGMT}")
    soft_assert(pages.get_text_iadl_nutrition_field() == IADL_NUTRITION,
                f"The actual-  {pages.get_text_iadl_nutrition_field()} value not much to the expected value- {IADL_NUTRITION}")
    soft_assert(pages.get_text_iadl_transportation_field() == IADL_TRANSPORTATION,
                f"The actual-  {pages.get_text_iadl_transportation_field()} value not much to the expected value- {IADL_TRANSPORTATION}")
    soft_assert(pages.get_text_adl_bath_field() == ADL_BATH,
                f"The actual-  {pages.get_text_adl_bath_field()} value not much to the expected value- {ADL_BATH}")
    soft_assert(pages.get_text_adl_dress_field() == ADL_DRESS,
                f"The actual-  {pages.get_text_adl_dress_field()} value not much to the expected value- {ADL_DRESS}")
    soft_assert(pages.get_text_adl_hygiene_field() == ADL_HYGINE,
                f"The actual-  {pages.get_text_adl_hygiene_field()} value not much to the expected value- {ADL_HYGINE}")
    soft_assert(pages.get_text_social_family_field() == SOCIAL_FAMILY,
                f"The actual-  {pages.get_text_social_family_field()} value not much to the expected value- {SOCIAL_FAMILY}")
    soft_assert(pages.get_text_social_friends_field() == SOCIAL_FRIENDS,
                f"The actual-  {pages.get_text_social_friends_field()} value not much to the expected value- {SOCIAL_FRIENDS}")
    soft_assert(pages.get_text_social_other_field() == SOCIAL_OTHER,
                f"The actual-  {pages.get_text_social_other_field()} value not much to the expected value- {SOCIAL_OTHER}")
    soft_assert(pages.get_text_social_religious_field() == SOCIAL_religious,
                f"The actual-  {pages.get_text_social_religious_field()} value not much to the expected value- {SOCIAL_religious}")
    soft_assert(pages.get_text_social_volunteering_field() == SOCIAL_volunteering,
                f"The actual-  {pages.get_text_social_volunteering_field()} value not much to the expected value- {SOCIAL_volunteering}")
    soft_assert(pages.get_text_hobbies_field() == HOBBIES,
                f"The actual-  {pages.get_text_hobbies_field()} value not much to the expected value- {HOBBIES}")
    soft_assert(pages.get_assistive_device_field() == ASSISTIVE_DEVICE,
                f"The actual-  {pages.get_assistive_device_field()} value not much to the expected value- {ASSISTIVE_DEVICE}")
    soft_assert(pages.get_text_health_status_field() == HEALTH_STATUS,
                f"The actual-  {pages.get_text_health_status_field()} value not much to the expected value- {HEALTH_STATUS}")
    soft_assert(pages.get_text_careplan_field() == CAREPLAN,
                f"The actual-  {pages.get_text_careplan_field()} value not much to the expected value- {CAREPLAN}")
    soft_assert(pages.get_text_num_medication_field() == NUM_MEDICATION,
                f"The actual-  {pages.get_text_num_medication_field()} value not much to the expected value- {NUM_MEDICATION}")
    soft_assert(pages.get_text_last_visit_pcp_field() == LAST_VISIT_PCP,
                f"The actual-  {pages.get_text_last_visit_pcp_field()} value not much to the expected value- {LAST_VISIT_PCP}")
    soft_assert(pages.get_text_num_falls_field() == NUM_FALLS,
                f"The actual-  {pages.get_text_num_falls_field()} value not much to the expected value- {NUM_FALLS}")
    soft_assert(pages.get_text_falls_medical_field() == FALLS_MEDICAL,
                f"The actual-  {pages.get_text_falls_medical_field()} value not much to the expected value- {FALLS_MEDICAL}")
    soft_assert(pages.get_text_num_hosp_field() == NUM_HOSP,
                f"The actual-  {pages.get_text_num_hosp_field()} value not much to the expected value- {NUM_HOSP}")
    soft_assert(pages.get_text_desireliv_field() == DESIRELIV,
                f"The actual-  {pages.get_text_desireliv_field()} value not much to the expected value- {DESIRELIV}")
    soft_assert(pages.get_text_beliefliv_field() == BELIEFLIV,
                f"The actual-  {pages.get_text_beliefliv_field()} value not much to the expected value- {BELIEFLIV}")
    verify_expectations()
    pages.closeTabs()
    pages.go_to_created_member()
    assert_that(QUESTONNAIRE_COMLETED).is_equal_to(pages.get_text_program_step())
    pages.go_to_member_detals()
    pages.delete_block_program()
    print("delete block program of member")
    pages.go_to_contact()
    pages.delete_contact()
    print("delete all contacts")


"""
Checked status of  "Care - kickoff awaiting care plan review"
In the care_kickoff screen select actions(high)
Select completed call ->Yes
"""


@allure.description("Care kickoff completed=Yes")
def test_care_kickoff_awaiting_care_plan_review(pages, general_flow, actions, assertion):
    pages.login(user_name, password)
    print("login finished")
    general_flow.onbourding_flow()
    pages.go_actions_section()
    pages.care_cikof_section()
    pages.click_on_next_button()
    pages.select_all_question_yes()
    pages.click_on_next_button()
    pages.select_form()
    pages.click_on_next_button()
    print("Care Kickoff page is open start verification of text and select actions")
    print("Finished checked selected checkbox\n")
    pages.select_complex_chronic()
    print("Select the ->Complex Chronic Conditions - Inadherence to Care Plan Actions")
    pages.select_complex_Chronic_action_send_vitals()
    pages.select_action_Arrange_home_modification()
    pages.select_action_send_assistive_device()
    pages.insert_text_in_text_box_carkicof()
    print("Inset text in text box in the carekicof page ")
    pages.select_yes_carkicof_compleate_call()
    pages.click_on_next_button()
    time.sleep(2)
    pages.select_no_follow_up()
    time.sleep(2)
    pages.click_on_next_button()
    pages.go_to_member()
    print("clicked on the member after onbourding process")
    time.sleep(3)
    assert_that(CARE_KICKOF_AWAITING_CARE_PLAN_REVIEW).is_equal_to(pages.get_text_program_step())
    pages.go_to_member_detals()
    pages.delete_block_program()
    print("delete block program of member")
    pages.go_to_contact()
    pages.delete_contact()
    print("delete all contacts")


"""
Checked status of  "Care - Active Action"
Flow ->create new member->onbourding ->care kicoff(select actions)
in the "Action executor" select "Approved by member/caregiver"
"""


@allure.description("When one or more ARF change its status to Open")
def test_care_active_action(pages, general_flow, actions, assertion):
    pages.login(user_name, password)
    print("login finished")
    general_flow.onbourding_flow()
    general_flow.care_kicoff_flow()
    pages.go_actions_section()
    pages.action_execution_section()
    pages.click_on_next_button()
    pages.select_all_question_yes()
    pages.click_on_next_button()
    pages.select_form()
    pages.click_on_next_button()
    pages.go_to_select_action_status()
    print("In the field of action status")
    pages.select_action_status()
    print("action status selected")
    pages.click_on_save_button()
    pages.click_on_next_button()
    time.sleep(2)
    pages.select_no_follow_up()
    time.sleep(2)
    pages.click_on_next_button()
    pages.go_to_member()
    print("clicked on the member after onbourding process")
    time.sleep(3)
    assert_that(CARE_ACTIVE_ACTION).is_equal_to(pages.get_text_program_step())
    pages.go_to_member_detals()
    pages.delete_block_program()
    print("delete block program of member")
    pages.go_to_contact()
    pages.delete_contact()
    print("delete all contacts")


"""
Checked status of  "Care - Kickoff in Process"
In the care kickoff select only no completed call
"""


@allure.description("When an ally starts filling care kickoff (when the flow starts)")
def test_care_kickoff_in_process_status(pages, general_flow, actions, assertion):
    pages.login(user_name, password)
    print("login finished")
    general_flow.onbourding_flow()
    pages.go_actions_section()
    pages.care_cikof_section()
    pages.click_on_next_button()
    pages.select_all_question_yes()
    pages.click_on_next_button()
    pages.select_form()
    pages.click_on_next_button()
    pages.select_no_carkicof_compleate_call_without_any_selection()
    pages.click_on_next_button()
    time.sleep(2)
    pages.select_no_follow_up()
    time.sleep(2)
    pages.click_on_next_button()
    pages.go_to_member()
    print("clicked on the member after care kickoff process")
    time.sleep(3)
    assert_that(CARE_KICKOFF_IN_PROCESS).is_equal_to(pages.get_text_program_step())
    pages.go_to_member_detals()
    pages.delete_block_program()
    print("delete block program of member")
    pages.go_to_contact()
    pages.delete_contact()
    print("delete all contacts")


"""
Test status "Care - passive (no-checkin)
In the Onbourding select Yes in the "meeting greet"
finished questionnaire ->Yes
"""


@allure.description("If member's level of touch scored as 'No' touch")
def test_care_passive_no_checkin_status(pages, general_flow, actions, assertion):
    pages.login(user_name, password)
    print("login finished")
    pages.closeTabs()
    general_flow.create_member()
    pages.go_to_created_member()
    print("clicked on the created member in home screen")
    pages.go_actions_section()
    print("click on the add button to display all section of functionality")
    pages.onbourding_section()
    print("select onbourding")
    pages.click_on_next_button()
    pages.select_all_question_yes()
    pages.click_on_next_button()
    pages.meet_greet_finished_questionnaire()
    time.sleep(2)
    pages.click_on_next_button()
    time.sleep(3)
    pages.select_no_follow_up()
    time.sleep(2)
    pages.click_on_next_button()
    pages.go_to_member()
    print("clicked on the member after onbourding process")
    time.sleep(3)
    assert_that(CARE_PASSIVE).is_equal_to(pages.get_text_program_step())
    pages.go_to_member_detals()
    pages.delete_block_program()
    print("delete block program of member")
    pages.go_to_contact()
    pages.delete_contact()
    print("delete all contacts")


"""
Checked the "Care - checkin" status
In the care kickoff not select anything
Select yes completed call
"""


@allure.description("If all ARFs actions' marked as completed in action execution OR No actions selected in Care "
                    "Kickoff")
def test_care_checkin_status(pages, general_flow, actions, assertion):
    pages.login(user_name, password)
    print("login finished")
    general_flow.onbourding_flow()
    pages.go_actions_section()
    pages.care_cikof_section()
    pages.click_on_next_button()
    pages.select_all_question_yes()
    pages.click_on_next_button()
    pages.select_form()
    pages.click_on_next_button()
    pages.select_yes_carkicof_compleate_call_without_any_selection()
    pages.click_on_next_button()
    time.sleep(2)
    pages.select_no_follow_up()
    time.sleep(2)
    pages.click_on_next_button()
    pages.go_to_member()
    print("clicked on the member after onbourding process")
    time.sleep(3)
    assert_that(CARE_CHECKIN).is_equal_to(pages.get_text_program_step())
    pages.go_to_member_detals()
    pages.delete_block_program()
    print("delete block program of member")
    pages.go_to_contact()
    pages.delete_contact()
    print("delete all contacts")


###################################
@allure.description("Check care kicoff flow with action and resolutions")
def test_carkicof(pages, general_flow, actions):
    pages.login(user_name, password)
    print("login finished")
    general_flow.onbourding_flow()
    pages.go_actions_section()
    pages.care_cikof_section()
    pages.click_on_next_button()
    pages.select_all_question_yes()
    pages.click_on_next_button()
    pages.select_form()
    pages.click_on_next_button()
    print("Care Kickoff page is open start verification of text and select actions")
    assert_that(pages.check_is_selected_checkBox_aDL_Bathing()).is_true()
    assert_that(pages.check_is_selected_checkBox_aDL_Dressing()).is_true()
    print("Finished checked selected checkbox\n")
    soft_assert(pages.get_text_from_ADL_Bathing() == ADL_BATHING, "The text of ADL_BATHING incorrect")
    soft_assert(pages.get_text_from_aDL_Dressing() == ADL_DRESSING, "The text of ADL_DRESSING incorrect")
    verify_expectations()
    pages.select_complex_chronic()
    soft_assert(pages.get_text_dark_blue_complex_Chronic_Conditions() == COMPLEX_CHRONIC,
                "The text of COMPLEX_CHRONIC incorrect")
    soft_assert(pages.get_text_question_Do_you_have_a_care_plan_from_your_doctor() == QUESTION_COMPLEX_CHRONIC,
                "The text of QUESTION_COMPLEX_CHRONIC incorrect")
    print("Select the ->Complex Chronic Conditions - Inadherence to Care Plan Actions")
    pages.select_complex_Chronic_action_send_vitals()
    soft_assert(pages.get_text_complex_Chronic_actions_title() == COMPLEX_CHRONIC_CONDITIONS_TITLE,
                "The text of COMPLEX_CHRONIC_CONDITIONS_TITLE incorrect")
    soft_assert(pages.get_text_send_vitals_log_action() == SEND_VITALS_LOG_ACTION,
                "The text of SEND_VITALS_LOG_ACTION incorrect")
    soft_assert(pages.get_text_send_vitals_equipment_action() == SEND_VITALS_EQUIPMENT_ACTION,
                "The text of SEND_VITALS_EQUIPMENT_ACTION incorrect")
    soft_assert(pages.get_text_send_med_logs_and_educational_action() == SEND_MED_LOGS_ACTION,
                "The text of SEND_MED_LOGS_ACTION incorrect")
    soft_assert(pages.get_text_set_up_of_Pillpack_action() == SET_UP_OF_PILLPACK_ACTION,
                "The text of SET_UP_OF_PILLPACK_ACTION incorrect")
    soft_assert(pages.get_text_set_up_of_med_delivery_action() == SET_UP_OF_MED_DELIVERY_ACTION,
                "The text of SET_UP_OF_MED_DELIVERY_ACTION incorrect")
    soft_assert(pages.get_text_set_up_member_with_local_action() == SET_UP_MEMBER_ACTION,
                "The text of SET_UP_MEMBER_ACTION incorrect")
    soft_assert(pages.get_text_set_up_ride_sharing_action() == SET_UP_RIDE_ACTION,
                "The text of SET_UP_MEMBER_ACTION incorrect")
    soft_assert(pages.get_text_set_up_GOGO_account_action() == SET_UP_GOGO_ACTION,
                "The text of SET_UP_GOGO_ACTION incorrect")
    print("Verify text in 'Complex Chronic Conditions - Inadherence to Care Plan Actions (question and all actions'")
    soft_assert(pages.get_text_arrange_home_safety_action() == ARRANGE_HOME_SAFETY_ACTION,
                "The text of ARRANGE_HOME_SAFETY_ACTION incorrect")
    soft_assert(pages.get_text_send_assistive_device_action() == SEND_ASSISTIVE_DEVICE_ACTION,
                "The text of SEND_ASSISTIVE_DEVICE_ACTION incorrect")
    soft_assert(pages.get_text_arrange_home_modification_action() == ARRANGE_HOME_MODIFICATION_ACTION,
                "The text of ARRANGE_HOME_MODIFICATION_ACTION incorrect")
    pages.select_action_Arrange_home_modification()
    soft_assert(pages.get_text_aDL_Dressing_actions_darkBlue_title() == ADL_DRESSING,
                "The text of ADL_DRESSING incorrect")
    soft_assert(pages.get_text_aDL_Dressing_question_What_is_difficult() == ADL_DRESSING_QUESTION_WHAT_IS_DIFFICULT,
                "The text of ADL_DRESSING_QUESTION_WHAT_IS_DIFFICULT incorrect")
    print("Verify actions in ADL Dressing and select Send assistive device action")
    soft_assert(pages.get_text_arrange_home_safety_Dressing_action() == ARRANGE_HOME_SAFETY_DRESSING_ACTION,
                "The text of ARRANGE_HOME_SAFETY_DRESSING_ACTION incorrect")
    soft_assert(pages.get_text_send_assistive_device_Dressing_action() == SEND_ASSISTIVE_DEVICE_DRESSING_ACTION,
                "The text of SEND_ASSISTIVE_DEVICE_DRESSING_ACTION incorrect")
    pages.select_action_send_assistive_device()
    pages.insert_text_in_text_box_carkicof()
    print("Inset text in text box in the carekicof page ")
    pages.select_yes_carkicof_compleate_call()
    pages.click_on_next_button()
    verify_expectations()
    time.sleep(2)
    pages.select_no_follow_up()
    time.sleep(2)
    pages.click_on_next_button()
    pages.go_to_onbourding_tab()
    time.sleep(5)
    assert_that(VALUEOF_LEVEL_OF_TOUCH).is_equal_to(pages.get_text_valueOf_level_of_Touch())
    print("Fineshed Verification value of Level of Touch")
    time.sleep(2)
    pages.go_to_form()
    pages.go_to_releated_tab()
    pages.go_to_releated_tab_inside_form()
    soft_assert(pages.get_text_aDL_Bathing_ARF_Name_Custom() == ADL_BATHING, "The text of ADL_BATHING incorrect")
    print("Verify the ADL Bathing ARF in Risk Factors success")
    soft_assert(pages.get_text_aDL_Dressing_ARF_Name_Custom() == ADL_DRESSING, "The text of ADL_DRESSING incorrect")
    soft_assert(
        pages.get_text_complex_Chronic_Conditions_ARF_Name_Custom() == COMPLEX_CHRONIC_CONDITIONS_ARF_NAME_CUSTOM,
        "The text of COMPLEX_CHRONIC_CONDITIONS_ARF_NAME_CUSTOM incorrect")
    verify_expectations()
    print("Finished verification of ARF's in Risk Factors\n ")
    print("Click on first Risk factor\n ")
    pages.click_on_first_risk_factor()
    print("Click on risk factor success")
    time.sleep(2)
    print("Click on the Related tab in risk factor")
    pages.go_to_releated_tab_in_risk_factor()
    print("Verify first The name of risk factor and check if the check nox 'isActive' is selected")
    assert_that(RESOLUTIONNAME_1).is_equal_to(pages.get_text_resolution_name_1())
    assert_that(pages.check_is_selected_checkBoxIsActive_resolution()).is_true()
    print("Click on the form of ARF in top bar\n ")
    pages.go_to_form_top_bar()
    print("Click on second Risk factor\n ")
    time.sleep(3)
    pages.go_to_risk_Factor_ADL_Dressing()
    pages.go_to_risck_factor_2()
    print("Verify second The name of risk factor and check if the check nox 'isActive' is selected")
    assert_that(RESOLUTIONNAME_2).is_equal_to(pages.get_text_resolution_name_2())
    assert_that(pages.check_is_selected_checkBoxIsActive_resolution()).is_true()
    print("Click on the form of ARF in top bar_3\n ")
    time.sleep(5)
    pages.go_to_form_top_bar()
    time.sleep(2)
    pages.go_to_third_risk_factor()
    pages.go_to_releated_tab_in_risck_factor3()
    print("Verify third The name of risk factor and check if the check nox 'isActive' is selected\n ")
    assert_that(RESOLUTIONNAME_3).is_equal_to(pages.get_text_resolution_name_3())
    assert_that(pages.check_is_selected_checkBoxIsActive_resolution()).is_true()
    pages.closeTabs()
    pages.go_to_contact()
    pages.go_to_created_member()
    pages.go_to_member()
    pages.go_to_member_detals()
    pages.delete_block_program()
    print("delete block program of member")
    pages.go_to_contact()
    pages.delete_contact()
    print("delete all contacts")

# # def test_create_new_campaign_assig_nmember_toit(pages, general_flow, actions, assertion):
# #         pages.login(user_name, password)
