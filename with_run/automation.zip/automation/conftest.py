
from pytest import fixture, hookimpl
from commonOps.actions import Actions
from commonOps.allure import Allure
from commonOps.assertions import Assertions
from commonOps.general_flow import General_flow
from commonOps.pages_init import PagesInit
from commonOps.common_functions import read_data_from_yaml
from commonOps.driver_factory import DriverFactory




@hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    # execute all other hooks to obtain the report object
    outcome = yield
    rep = outcome.get_result()

    # set a report attribute for each phase of a call, which can
    # be "setup", "call", "teardown"

    setattr(item, "rep_" + rep.when, rep)

def pytest_addoption(parser):
    parser.addoption(
        "--env",
        action="store",
        default="staging",
        help="env: staging or prod"
    )
    parser.addoption('--project',
                     action='store',
                     default='age_assured',
                     help='project: age_assured or neverstop')


@fixture
def env(request):
    return request.config.getoption("--env")


@fixture
def project_name(request):
    return request.config.getoption("--project")


@fixture
def url(project_name, env):
    url_env = 'url_staging' if env == 'staging' else 'url_prod'
    return read_data_from_yaml('config', project_name, url_env)


@fixture
def browser(request):
    """
    Init webdriver from factory class using the get_driver method
    :return: webdriver instance
    NOTE: we use here the 'yield' keyword to perform the quit action on the browser once the test is done.
    """
    driver_factory = DriverFactory()
    driver = driver_factory.get_driver()
    yield driver
    if request.node.rep_call.failed:
        Allure(driver).attach_screenshot()
    driver.close()



@fixture
def pages(url, browser):
    pages = PagesInit(browser)
    pages.w.get(url)
    return pages


@fixture
def actions(browser):
    return Actions(browser)


@fixture
def assertion():
    return Assertions()

@fixture
def general_flow(browser):
    return General_flow(browser)






